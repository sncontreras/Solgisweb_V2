import 'package:flutter/material.dart';

class RegistrarImagePage extends StatelessWidget {
  const RegistrarImagePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
