import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:solgis/projects/image/domain/image_foto.dart';

class HomePageImage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(centerTitle: true, title: const Text('Image V2')),
      body: Center(
        child: Consumer<FotoProvider>(
          builder: (context, fotoProvider, _) {
            return fotoProvider.foto == null
                ? FutureBuilder<void>(
                    future: fotoProvider
                        .tomarFotoDirecto(), // Utiliza el método para abrir la cámara directamente
                    builder:
                        (BuildContext context, AsyncSnapshot<void> snapshot) {
                      if (snapshot.connectionState == ConnectionState.done) {
                        return Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Expanded(
                              child: Image.file(
                                File(fotoProvider.foto!.path),
                                fit: BoxFit.cover,
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                IconButton(
                                  onPressed: () {
                                    fotoProvider
                                        .limpiarFoto(); // Limpiar la foto actual
                                  },
                                  icon: const Icon(Icons.refresh),
                                ),
                                IconButton(
                                  onPressed: () {
                                    // Aquí puedes implementar la lógica para aceptar la foto
                                    // Por ejemplo, guardarla o procesarla.
                                  },
                                  icon: const Icon(Icons.check),
                                ),
                              ],
                            ),
                          ],
                        );
                      } else {
                        return const CircularProgressIndicator(); // Muestra un indicador de carga mientras se abre la cámara
                      }
                    },
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Image.file(
                          File(fotoProvider.foto!.path),
                          fit: BoxFit.cover,
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            onPressed: () {
                              fotoProvider
                                  .limpiarFoto(); // Limpiar la foto actual
                            },
                            icon: const Icon(Icons.refresh),
                          ),
                          IconButton(
                            onPressed: () {
                              // Aquí puedes implementar la lógica para aceptar la foto
                              // Por ejemplo, guardarla o procesarla.
                            },
                            icon: const Icon(Icons.check),
                          ),
                        ],
                      ),
                    ],
                  );
          },
        ),
      ),
    );
  }
}
